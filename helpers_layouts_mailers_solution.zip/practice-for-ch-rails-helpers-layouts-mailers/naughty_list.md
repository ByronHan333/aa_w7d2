app/mailers/user_mailer.rb
app/mailers/application_mailer.rb
app/views/user_mailer/
app/views/layouts/mailer.text.erb
app/views/layouts/mailer.html.erb
