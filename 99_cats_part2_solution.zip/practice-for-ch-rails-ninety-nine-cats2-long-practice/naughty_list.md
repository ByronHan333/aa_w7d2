db/migrate/20220610145144_create_users.rb
db/migrate/20220610214850_add_owner_to_cats.rb
db/migrate/20220618214048_add_requester_to_cat_rental_requests.rb
app/models/user.rb
app/controllers/sessions_controller.rb
app/controllers/users_controller.rb
app/views/users/
app/views/sessions/
