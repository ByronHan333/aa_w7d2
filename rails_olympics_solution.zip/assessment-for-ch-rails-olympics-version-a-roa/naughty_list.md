blog_app/db/migrate/
blog_app/app/models/blog.rb
blog_app/app/models/comment.rb
blog_app/app/models/user.rb
blog_app/app/controllers/blogs_controller.rb
blog_app/app/controllers/comments_controller.rb
blog_app/app/controllers/users_controller.rb
