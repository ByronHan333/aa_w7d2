# == Schema Information
#
# Table name: users
#
#  id         :bigint           not null, primary key
#  username   :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class User < ApplicationRecord
  validates :username, presence: true, uniqueness: true
  
  has_many :flowers, foreign_key: :gardener_id, dependent: :destroy, inverse_of: :gardener

  has_many :gardens, foreign_key: :garden_owner_id, dependent: :destroy, inverse_of: :garden_owner

  #  Find all the flowers that are in this user's gardens, whether they belong
  #  to this user or not.
  has_many :flowers_in_all_gardens, through: :gardens, source: :flowers

  #  Find all the gardens that has this user's flowers.
  has_many :gardens_with_my_flowers, through: :flowers, source: :garden
end